//Arthur Busanello  e Bruno Gabriel

//Libraries
#include "raylib.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>




//TADS
#include "TADs/menu.h"
#include "TADs/estruturas_uno.h"
#include "TADs/funcoes_uno.h"
#include "TADs/pilha_enc.h"
#include "TADs/lista_circ_enc_dupla.h"
#include "TADs/lista_enc_dupla.h"
#include "TADS/jogo.h"

//Preciso fazer essas texturas como globais porque se não seria uma mão de passar +20 parametros por função
//desculpa thiago
Texture2D inverteVermelho; //texturas cartas
Texture2D inverteVerde;
Texture2D inverteAzul;
Texture2D inverteAmarelo;
Texture2D compraVermelho;
Texture2D compraVerde;
Texture2D compraAzul;
Texture2D compraAmarelo;
Texture2D bloqueioVermelho;
Texture2D bloqueioVerde;
Texture2D bloqueioAzul;
Texture2D bloqueioAmarelo;
Texture2D vermelho9;
Texture2D verde9;
Texture2D azul9;
Texture2D amarelo9;
Texture2D vermelho8;
Texture2D verde8;
Texture2D azul8;
Texture2D amarelo8;
Texture2D vermelho7;
Texture2D verde7;
Texture2D azul7;
Texture2D amarelo7;
Texture2D vermelho6;
Texture2D verde6;
Texture2D azul6;
Texture2D amarelo6;
Texture2D vermelho5;
Texture2D verde5;
Texture2D azul5;
Texture2D amarelo5;
Texture2D vermelho4;
Texture2D verde4;
Texture2D azul4;
Texture2D amarelo4;
Texture2D vermelho3;
Texture2D verde3;
Texture2D azul3;
Texture2D amarelo3;
Texture2D vermelho2;
Texture2D verde2;
Texture2D azul2;
Texture2D amarelo2;
Texture2D vermelho1;
Texture2D verde1;
Texture2D azul1;
Texture2D amarelo1;
Texture2D vermelho0;
Texture2D verde0;
Texture2D azul0;
Texture2D amarelo0;
Texture2D coringa;
Texture2D compra4;

//Tivemos que deixar essa função aqui para funcionar
void DesenhaCarta(Carta carta, int posX, int posY) {
    Texture2D texturaCarta;

    // Seleciona a textura da carta com base no tipo
    switch (carta.tipo) {
        case AZUL:
            if(carta.chave == 0 )
                texturaCarta = azul0;
            if(carta.chave == 1 )
                texturaCarta = azul1;
            if(carta.chave == 2 )
                texturaCarta = azul2;
            if(carta.chave == 3 )
                texturaCarta = azul3;
            if(carta.chave == 4 )
                texturaCarta = azul4;
            if(carta.chave == 5 )
                texturaCarta = azul5;
            if(carta.chave == 6 )
                texturaCarta = azul6;
            if(carta.chave == 7 )
                texturaCarta = azul7;
            if(carta.chave == 8 )
                texturaCarta = azul8;
            if(carta.chave == 9 )
                texturaCarta = azul9;
            if(carta.chave == 10 )
                texturaCarta = bloqueioAzul;
            if(carta.chave == 11 )
                texturaCarta = inverteAzul;
            if(carta.chave == 12 )
                texturaCarta = compraAzul;

            break;
        case AMARELO:
            if(carta.chave == 0 )
                texturaCarta = amarelo0;
            if(carta.chave == 1 )
                texturaCarta = amarelo1;
            if(carta.chave == 2 )
                texturaCarta = amarelo2;
            if(carta.chave == 3 )
                texturaCarta = amarelo3;
            if(carta.chave == 4 )
                texturaCarta = amarelo4;
            if(carta.chave == 5 )
                texturaCarta = amarelo5;
            if(carta.chave == 6 )
                texturaCarta = amarelo6;
            if(carta.chave == 7 )
                texturaCarta = amarelo7;
            if(carta.chave == 8 )
                texturaCarta = amarelo8;
            if(carta.chave == 9 )
                texturaCarta = amarelo9;
            if(carta.chave == 10 )
                texturaCarta = bloqueioAmarelo;
            if(carta.chave == 11 )
                texturaCarta = inverteAmarelo;
            if(carta.chave == 12 )
                texturaCarta = compraAmarelo;
            break;
        case VERMELHO:
            if(carta.chave == 0 )
                texturaCarta = vermelho0;
            if(carta.chave == 1 )
                texturaCarta = vermelho1;
            if(carta.chave == 2 )
                texturaCarta = vermelho2;
            if(carta.chave == 3 )
                texturaCarta = vermelho3;
            if(carta.chave == 4 )
                texturaCarta = vermelho4;
            if(carta.chave == 5 )
                texturaCarta = vermelho5;
            if(carta.chave == 6 )
                texturaCarta = vermelho6;
            if(carta.chave == 7 )
                texturaCarta = vermelho7;
            if(carta.chave == 8 )
                texturaCarta = vermelho8;
            if(carta.chave == 9 )
                texturaCarta = vermelho9;
            if(carta.chave == 10 )
                texturaCarta = bloqueioVermelho;
            if(carta.chave == 11 )
                texturaCarta = inverteVermelho;
            if(carta.chave == 12 )
                texturaCarta = compraVermelho;
            break;
        case VERDE:
            if(carta.chave == 0 )
                texturaCarta = verde0;
            if(carta.chave == 1 )
                texturaCarta = verde1;
            if(carta.chave == 2 )
                texturaCarta = verde2;
            if(carta.chave == 3 )
                texturaCarta = verde3;
            if(carta.chave == 4 )
                texturaCarta = verde4;
            if(carta.chave == 5 )
                texturaCarta = verde5;
            if(carta.chave == 6 )
                texturaCarta = verde6;
            if(carta.chave == 7 )
                texturaCarta = verde7;
            if(carta.chave == 8 )
                texturaCarta = verde8;
            if(carta.chave == 9 )
                texturaCarta = verde9;
            if(carta.chave == 10 )
                texturaCarta = bloqueioVerde;
            if(carta.chave == 11 )
                texturaCarta = inverteVerde;
            if(carta.chave == 12 )
                texturaCarta = compraVerde;
            break;
        case ESPECIAL:
            if(carta.chave == 13)
                texturaCarta = coringa;
            if(carta.chave == 14)
                texturaCarta = compra4;
            break;
        default:
            // Lida com casos inválidos
            break;
    }

    // Desenha a textura da carta na posição especificada
    DrawTexture(texturaCarta, posX, posY, WHITE);
}

//Main
int main(void)
{
    //VARIAVEIS
    // Inicializa o baralho
    PilhaEnc* baralho = inicializaBaralhoUno();
    for(int i = 0; i < 2; i++){
        Carta cartaTeste = desempilhaPilhaEnc(baralho);
        printf("%d %d \n", cartaTeste.chave, cartaTeste.tipo);
    }
    TipoCarta corObrigatoria = -1; // Valor -1 não é obrigatório jogar uma cor específica, muda com carta coringa
    int uno = 0; //

    // Número de jogadores e número de cartas que cada jogador receberá inicialmente
    int numJogadores = 2;
    int numCartasPorJogador = NUM_MAO_INICIO;

    // Cria e inicializa os jogadores
    ListaCirc2* ordemJogadores = criaListaCirc2();
    Jogador* jogador;
    int ordem = 0; // Marcador de direção da ordem de jogadores
    for(int i = 0; i < numJogadores; i++){
        jogador = inicializaJogador(i + 1); // IDs de jogadores começam em 1
        insereFimListaCirc2(ordemJogadores, jogador);
        printf("Jogador %d na partida! \n", (ordemJogadores->prim)->ant->jogador->id); // Printa o id do ultimo jogador adicionado
    }

    // Distribui cartas para os jogadores
    NodoLCirc2* nodoJogador = ordemJogadores->prim;
    for(int i = 0; i < numJogadores; i++){
        for(int j = 0; j < numCartasPorJogador; j++){
            if(compraCarta(baralho, nodoJogador->jogador->mao) == 1){
                printf("Jogador %d, Carta %d adcionada na mao. \n", nodoJogador->jogador->id, j+1);
            }
        }
        nodoJogador = nodoJogador->prox; // Avança para o próximo jogador na lista circular
    }
    //Inicializando a Mesa
    PilhaEnc* cartasdaMesa = criaPilhaEnc();
    primeiraCartaMesa(baralho, cartasdaMesa);
    Mesa* mesa = InicializaMesa(baralho, ordemJogadores, numJogadores); //funcionou

    //Menu Inicialization
    InitAudioDevice();
    Menu* menu = InitMenu();
    //Aduio Inicialization
    Audio* menuMusic = InitAudio("music/meu_lugar.mp3"); //Menu music
    PlayAudio(menuMusic);
    Audio* menuStart = InitAudio("music/eu-carrego.mp3"); //Menu start
    PlayAudio(menuStart);


    //Textures Inicialization, eu sei que daria para fazer uma função para tudo isso mas não temos tempo desuclpe
    Texture2D audioIcon = LoadTexture("textures/audio-icon.png"); //textures do menu
    Texture2D redX = LoadTexture("textures/red-x.png");
    Texture2D background = LoadTexture("textures/escola_br.png");
    Texture2D mesaRabiscada = LoadTexture("textures/mesa_rabiscada.png"); //texturas jogo
    Texture2D cartaCostas = LoadTexture("textures/ben10uno.png"); 
    inverteVermelho = LoadTexture("textures/cartas/inverteVermelho.png"); //texturas cartas
    inverteVerde = LoadTexture("textures/cartas/inverteVerde.png");
    inverteAzul = LoadTexture("textures/cartas/inverteAzul.png");
    inverteAmarelo = LoadTexture("textures/cartas/inverteAmarelo.png"); //todos inverte
    compraVermelho = LoadTexture("textures/cartas/compraVermelho.png");
    compraVerde = LoadTexture("textures/cartas/compraVerde.png");
    compraAzul = LoadTexture("textures/cartas/compraAzul.png");
    compraAmarelo = LoadTexture("textures/cartas/compraAmarelo.png"); //todos os compra2
    bloqueioVermelho = LoadTexture("textures/cartas/bloqueioVermelho.png");
    bloqueioVerde = LoadTexture("textures/cartas/bloqueioVerde.png");
    bloqueioAzul = LoadTexture("textures/cartas/bloqueioAzul.png");
    bloqueioAmarelo = LoadTexture("textures/cartas/bloqueioAmarelo.png"); //todos os bloqueios
    vermelho9 = LoadTexture("textures/cartas/9vermelho.png");
    verde9 = LoadTexture("textures/cartas/9verde.png");
    azul9 = LoadTexture("textures/cartas/9azul.png");
    amarelo9 = LoadTexture("textures/cartas/9amarelo.png"); // todos os 9
    vermelho8 = LoadTexture("textures/cartas/8vermelho.png");
    verde8 = LoadTexture("textures/cartas/8verde.png");
    azul8 = LoadTexture("textures/cartas/8azul.png");
    amarelo8 = LoadTexture("textures/cartas/8amarelo.png"); //todos os 8
    vermelho7 = LoadTexture("textures/cartas/7vermelho.png");
    verde7 = LoadTexture("textures/cartas/7verde.png");
    azul7 = LoadTexture("textures/cartas/7azul.png");
    amarelo7 = LoadTexture("textures/cartas/7amarelo.png"); //todos os 7
    vermelho6 = LoadTexture("textures/cartas/6vermelho.png");
    verde6 = LoadTexture("textures/cartas/6verde.png");
    azul6 = LoadTexture("textures/cartas/6azul.png");
    amarelo6 = LoadTexture("textures/cartas/6amarelo.png");//todos os 6
    vermelho5 = LoadTexture("textures/cartas/5vermelho.png");
    verde5 = LoadTexture("textures/cartas/5verde.png");
    azul5 = LoadTexture("textures/cartas/5azul.png");
    amarelo5 = LoadTexture("textures/cartas/5amarelo.png");//todos os 5
    vermelho4 = LoadTexture("textures/cartas/4vermelho.png");
    verde4 = LoadTexture("textures/cartas/4verde.png");
    azul4 = LoadTexture("textures/cartas/4azul.png");
    amarelo4 = LoadTexture("textures/cartas/4amarelo.png");//todos os 4
    vermelho3 = LoadTexture("textures/cartas/3vermelho.png");
    verde3 = LoadTexture("textures/cartas/3verde.png");
    azul3 = LoadTexture("textures/cartas/3azul.png");
    amarelo3 = LoadTexture("textures/cartas/3amarelo.png"); //todos os 3
    vermelho2 = LoadTexture("textures/cartas/2vermelho.png");
    verde2 = LoadTexture("textures/cartas/2verde.png");
    azul2 = LoadTexture("textures/cartas/2azul.png");
    amarelo2 = LoadTexture("textures/cartas/2amarelo.png"); //todos 2
    vermelho1 = LoadTexture("textures/cartas/1vermelho.png");
    verde1 = LoadTexture("textures/cartas/1verde.png");
    azul1 = LoadTexture("textures/cartas/1azul.png");
    amarelo1 = LoadTexture("textures/cartas/1amarelo.png"); //todos 1
    vermelho0 = LoadTexture("textures/cartas/0vermelho.png");
    verde0 = LoadTexture("textures/cartas/0verde.png");
    azul0 = LoadTexture("textures/cartas/0azul.png");
    amarelo0 = LoadTexture("textures/cartas/0amarelo.png"); //todos os 0
    coringa = LoadTexture("textures/cartas/coringa.png");
    compra4 = LoadTexture("textures/cartas/compra4.png"); //coringa e compra 4





    // Main game loop
    while (!WindowShouldClose()) //While Esc or leave window(x) arent pressed
    {

        // Desenha o menu de acordo com o valor de loop
        switch (menu->loop) {
            case 0: // Menu principal
                ProcessMenuInput(menu, menuMusic);
                BeginDrawing(); //Drawing
                ClearBackground(RAYWHITE); //limpa a tela pra desenhar
                DrawMenu(menu, menuMusic, audioIcon, redX, background);
                break;
            case 1: // Loop do jogo
                // Inicia desenho das:
                    // Cartas dos jogador 1
                    // Cartas dos jogador i
                    // Carta mesa->topo
                    // Carta baralho virada para baixo

                jogada(baralho, cartasdaMesa,ordemJogadores,&corObrigatoria);

                // Verifica cartas especiais
                // Funcao carta Pula
                cartaPula(cartasdaMesa, ordemJogadores);
                // Funcao carta Reverter
                cartaReverter(cartasdaMesa, &ordem);
                // Funcao carta Compra2
                cartaCompra2(cartasdaMesa, ordemJogadores, baralho);
                //Função carta Coringa Escolhe Cor VAI AO FINAL DA JOGADA
                cartaCoringaEscolheCor(cartasdaMesa, &corObrigatoria);
                // Função carta Coringa Compra 4
                cartaCoringaCompra4(cartasdaMesa, ordemJogadores, &corObrigatoria, baralho);


                if(verificaGanhador(ordemJogadores) == 1){
                    ClearBackground(RAYWHITE); //limpa a tela pra desenhar
                    DrawText("Você ganhou!!!", GetScreenWidth(), GetScreenHeight(), 70, RED);
                    DrawText("P para voltar", 750, 390, 40, YELLOW);
                }

                ClearBackground(RAYWHITE);
                DesenhaMesa(mesa, baralho, mesaRabiscada, cartaCostas);

                //volta para o menu
                DrawText("P", 750, 390, 40, YELLOW);
                if(IsKeyPressed(KEY_P)){ //enquanto n voltamos pro menu
                    menu->loop = 0;
                }
                break;
            case 2: // Loop do boss
            // Aqui você colocaria o loop do boss
                break;
            case 3: // Loop do load
            // Aqui você colocaria o loop do load
                break;
            case 4: // Loop da configuração
            // Aqui você colocaria o loop da configuração
                break;
            default:
                menu->loop = 0; //volta pro menu se der ruim
                break;
    }
        EndDrawing(); //End Drawing

    } //Left Game loop

    CloseWindow();  //Close the Windown
    CloseAudioDevice();

    //Freeing memory space
    free(menu);
    UnloadTexture(audioIcon);


    // Libera a memória alocada para o baralho e para os jogadores
    destroiPilhaEnc(baralho);
    for (int i = 0; i < numJogadores; i++) {
        destroiJogador(ordemJogadores->prim->jogador);
    }
    destroiListaCirc2(ordemJogadores);

    return 0;
}

